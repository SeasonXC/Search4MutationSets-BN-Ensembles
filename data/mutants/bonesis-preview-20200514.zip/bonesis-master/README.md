install with
```
pip install --user -e .
```
